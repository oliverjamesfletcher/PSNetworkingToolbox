﻿#Clear console
Clear-Host
$a = (Get-Host).UI.RawUI
#Add Title to Console window
$a.WindowTitle = "Networking Toolbox Version 1.0"
#Change console background to black
$host.UI.RawUI.BackgroundColor = "Black"
#Get the PowerShell Host
$pshost = Get-Host
#Get the PowerShell Host's UI              
$pswindow = $pshost.UI.RawUI    
#Get the UI's current Window Size
$newsize = $pswindow.windowsize 
#Set the new Window Width to 220 columns.
$newsize.width = 220         
#Set the new Window Size as active.   
$pswindow.windowsize = $newsize 
#Clear console
Clear-Host
Write-Host "Welcome to the Networking Toolbox Version 1.0" -ForegroundColor White
Write-Host "By Oliver J. Fletcher" -ForegroundColor White
#Create menu options
Write-Host "----------------------------------------------------------------------------" -ForegroundColor White
[int]$xMenuChoiceA = 0
while ( $xMenuChoiceA -lt 1 -or $xMenuChoiceA -gt 27 ){
Write-host "1. ipconfig /all - Displays the full TCP/IP configuration for all adapters" -ForegroundColor Green
Write-host "2. ipconfig /flushdns -  Flushes and resets the contents of the DNS client resolver cache" -ForegroundColor Green
Write-host "3. netstat - Active TCP connections, ports, Ethernet statistics, the IP routing table,and IPv4 and IPv6 statistics" -ForegroundColor Green
Write-host "4. netstat -a - Displays all active TCP connections and the TCP and UDP ports on which the computer is listening" -ForegroundColor Green
Write-host "5. nslookup - Lookup IP addresses on a NameServer" -ForegroundColor Green
Write-host "6. tracert - Determine the path that an IP packet has taken to reach a destination" -ForegroundColor Green
Write-Host "7. pathping - Trace route and provide network latency and packet loss for each router and link in the path." -ForegroundColor Green
Write-host "8. netsh int ip reset all - Reset TCP/IP" -ForegroundColor Green
Write-host "9. ping - The ping command displays whether the destination responded and how long it took to receive a reply" -ForegroundColor Green
Write-host "10. ping -t - Ping the destination host until interrupted." -ForegroundColor Green
Write-host "11. telnet - Check if a certain port is open on a host" -ForegroundColor Green
Write-host "12. getmac - Get the MAC Adddress of a device" -ForegroundColor Green
Write-host "13. arp -a - Display current ARP entries." -ForegroundColor Green
Write-host "14. hostname - Get hostname and domain. " -ForegroundColor Green
Write-host "15. route add - Add route with variables to routing table." -ForegroundColor Green
Write-host "16. route add if - Add route, select NIC Index and update routing table." -ForegroundColor Green
Write-host "17. route add if metric - Add route, select NIC Index, give preference and update routing table." -ForegroundColor Green
Write-host "18. route -p add - Add persistent route with variables to routing table." -ForegroundColor Green
Write-host "19. route -p add if - Add persistent route, set variables, select NIC and add to routing table." -ForegroundColor Green
Write-host "20. route delete - Remove route and variables from routing table." -ForegroundColor Green
Write-host "21. Clear screen and exit" -ForegroundColor Green
Write-host "Note: ~ Command number 8, 15, 16, 18, 19 and 20 will need to be run as Admin ~" -ForegroundColor Red
Write-Host "----------------------------------------------------------------------------" -ForegroundColor White
#Set seletion paths for menu options
[Int]$xMenuChoiceA = read-host "Please enter script number to run - 1 to 21"}
Switch( $xMenuChoiceA ){
   1{Clear-Host 
    cd "C:\Scripts"
    .\IPConfig_all.ps1}
  2{Clear-Host 
    cd "C:\Scripts"
    .\IPConfig_Flush_DNS.ps1}
  3{Clear-Host 
    cd "C:\Scripts"
    .\Netstat.ps1}
  4{Clear-Host 
    cd "C:\Scripts"
    .\Netstat_a.ps1} 
 5{Clear-Host 
    cd "C:\Scripts"
    .\NSLookup.ps1}
  6{Clear-Host 
    cd "C:\Scripts"
    .\TraceRT.ps1}
  7{Clear-Host 
    cd "C:\Scripts"
    .\PathPing.ps1}
  8{Clear-Host 
    cd "C:\Scripts"
    .\NetSh_int_reset_all.ps1}
  9{Clear-Host 
    cd "C:\Scripts"
    .\Ping.ps1}
 10{Clear-Host 
    cd "C:\Scripts"
    .\Ping_t.ps1}
  11{Clear-Host 
    cd "C:\Scripts"
    .\Telnet.ps1}
  12{Clear-Host 
    cd "C:\Scripts"
    .\Get_Mac.ps1}
  13{Clear-Host 
    cd "C:\Scripts"
    .\ARP_a.ps1}
  14{Clear-Host 
    cd "C:\Scripts"
    .\Get-Hostname2.ps1}
  15{Clear-Host 
    cd "C:\Scripts"
    .\Route_Add.ps1}
  16{Clear-Host 
    cd "C:\Scripts"
    .\Route_Add_Index.ps1}
  17{Clear-Host 
    cd "C:\Scripts"
    .\Route_Add_Metric_NIC.ps1}
  18{Clear-Host A
    cd "C:\Scripts"
    .\Route_Add_Persistent.ps1}
  19{Clear-Host 
    cd "C:\Scripts"
    .\Route_Add_Persistent_NIC.ps1}
  20{Clear-Host 
    cd "C:\Scripts"
    .\Route_Delete.ps1}
  21{cls
        exit}
default{
cd C:\Scripts
.\Networking_Toolbox.ps1}
} 



