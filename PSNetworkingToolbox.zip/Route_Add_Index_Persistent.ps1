﻿#Add IP Address to Route table by fletcol
#Set Hostname or IP Address
$Desination = (read-host "Enter IP Address for Desination") 
#Set Subnet Mask
$SubnetMask = (read-host "Enter Subnet Mask") 
#Set Gateway
$Gateway = (read-host "Enter Gateway IP Address") 
PAUSE
Get-WmiObject win32_networkadapterconfiguration -Filter 'ipenabled = "true"' | select IPAddress, Index | Format-List
$NICIndex = (read-host "Enter NIC Index number") 
#Add IP Address Desination to Route Table
route -p add $Destination mask $SubnetMask $Gateway if $NICIndex
#Pause before returning to menu
cmd /c pause | out-null
#Write message to return to menu
Write-Host -NoNewLine 'Press any key to return to menu...';
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
#Return to Menu
cd C:\Scripts
.\Networking_Toolbox.ps1