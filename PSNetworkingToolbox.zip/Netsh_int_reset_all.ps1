﻿ #Reset TCP/IP
 netsh int ip reset all