﻿#Get NIC properties of Hostname or IP Address by fletcol
ipconfig /all
PAUSE
#Write message to return to menu
Write-Host -NoNewLine 'Press any key to return to menu...';
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
#Return to Menu
cd C:\Scripts
.\Networking_Toolbox.ps1