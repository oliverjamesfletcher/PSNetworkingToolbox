﻿#Pathping a Hostname or IP Address by fletcol
#Set Hostname or IP Address
$Hostname = (read-host "Enter Hostname or IP Address") 
pathping $Hostname
PAUSE
#Write message to return to menu
Write-Host -NoNewLine 'Press any key to return to menu...';
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
#Return to Menu
cd C:\Scripts
.\Networking_Toolbox.ps1